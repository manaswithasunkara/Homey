package com.example.homey;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
