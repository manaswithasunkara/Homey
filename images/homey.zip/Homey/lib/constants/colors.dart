import 'package:flutter/material.dart';

class AppColors{
static const turquoisePrimary= Color(0xff3270fc);
static const blackPrimary= Colors.black;
static const appbarColor= Color(0xffebeef3);
static const textHeading1= Color(0xff282828);
static const grey= Colors.grey;
static const homeyColor= Color(4282015859);
static const heading= Colors.black45;
static const bgcolor= Color(4294309883);
static const bgcolor2=Color(0xfff9f9f9);
static const aboutHeading= Color(4283853189);
static const textColor= Color(4279517811);
static const indigoBlue= Color(4283853204);
static const lavenderPink= Color(4292326643);

}